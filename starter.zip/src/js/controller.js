// import icons from '../img/icons/svg' // Parcel 1

import * as module from './module.js'
import recipeView from './views/recipeView.js'

import 'core-js/stable'
import 'regenerator-runtime/runtime'



const recipeContainer = document.querySelector('.recipe');

const timeout = function (s) {
  return new Promise(function (_, reject) {
    setTimeout(function () {
      reject(new Error(`Request took too long! Timeout after ${s} second`));
    }, s * 1000);
  });
};

// https://forkify-api.herokuapp.com/v2

///////////////////////////////////////



console.log('Test');

const controlRecipes = async function () {
  try{

    const id = window.location.hash.slice(1)

    if (!id) return

    recipeView.renderSpinner()
    // 1) loading recipe
    await module.loadRecipe(id)

    // 2) Rendering recipe

    recipeView.render(module.state.recipe)
    
  }catch(err){
    alert(err);
  }
}

console.log(typeof controlRecipes);
['hashchange', 'load'].forEach(ev => window.addEventListener(ev, controlRecipes))

